# Westfield Municipal — 1984 Discord RP Bot

A GitHub-ready Discord project for a **fictional 1984 town** with two separate kinds of bulletin:

- **FICTIONAL ROLEPLAY** — realistic everyday town notices, school events, family gossip, employment, crimes, and occasional supernatural happenings. These are prompts, never facts about player-owned characters.
- **REAL HISTORY** — small, curated, **source-linked historical events that really happened in 1984**. Add verified historical items to `data/events.json` as you develop the calendar.

## Recommended: GitHub-only scheduled notices, no paid hosting

This uses **GitHub Actions + a Discord Webhook**. It posts twice per week on Mondays and Thursdays at 2:17 p.m. New York time (subject to GitHub scheduling delays). You can also publish manually whenever you want. **It is not an always-online slash-command bot.**

1. Go to [GitHub](https://github.com/new) and make a repository, e.g. `westfield-municipal`. Upload **the contents of this ZIP**, keeping the `.github/workflows` folder structure. For automated scheduled Actions, use the default branch and enable Actions in repository settings.
2. In Discord, create a private or public #town-bulletins channel. Open **Edit Channel → Integrations → Webhooks → New Webhook**. Copy the webhook URL. Keep it private, just like a password.
3. In GitHub open **Repository → Settings → Secrets and variables → Actions → New repository secret**. Name it `DISCORD_WEBHOOK_URL` and paste your Discord webhook URL as the secret value.
4. On GitHub open **Actions → Post 1984 town bulletin → Run workflow**. Choose `mixed`, `town`, or `history`; optionally enter `1984-01-24` as the in-game date. Try `history` with `1984-01-24` to guarantee a starter historic story.
5. After it works, the workflow posts automatically twice weekly. You can edit `cron` in `.github/workflows/town-bulletin.yml` to adjust the schedule. GitHub scheduled runs may be delayed; public repo schedules may deactivate after 60 days with no activity.

**Note on date handling:** `RP_DATE` controls the in-story date for manual Actions runs. Blank means today's **real month/day**, used as an anniversary-style filter for historical stories. If there is no curated historic event that day, `mixed` falls back to fictional events. `history` deliberately errors rather than inventing a fake historical fact.

## Optional: slash commands `/event`, `/history`, `/townhelp`

This requires the Python bot process to be running on your computer or a persistent bot hosting service. GitHub alone does not run this continuous process.

1. At https://discord.com/developers/applications create a New Application. Under **Bot**, generate and copy the secret token. On **Installation**, use Guild Install with `bot` and `applications.commands` scopes, and give Send Messages and Embed Links permissions. Install into your server.
2. Install Python 3.10+ and run `pip install -r requirements.txt` in the project directory.
3. Copy `.env.example` to `.env`, set `DISCORD_TOKEN=...` and optionally `DISCORD_GUILD_ID` for fast command registration in one test server. **Never commit `.env`**.
4. Run `python bot.py`. Try `/event` and `/history` in your server. Global commands can take time to appear, but a test guild usually syncs faster.

## Edit the town

- Change the name `Westfield` in `post_bulletin.py`, `events.py` and `bot.py` when you choose a final town name.
- Add fictional hooks in `data/events.json` under `fictional` using `title`, `description`, `hook`.
- Add sourced historic entries in `history` using `month`, `day`, `title`, `description`, and `source`. Verify real facts before publishing; don't turn tragic world events into comedy or claim characters participated without player consent.
- To make history posts on more in-world days, add more sourced entries. This starter intentionally has only three.

## Safety and moderation

Player-character weddings, illnesses, injuries, births, arrests, or deaths require player approval; the starter bot only creates anonymous opportunities. No tracking of real people, no automatic mentions. Keep tokens and webhook URLs in secrets, not source files. Don't enable unneeded privileged bot intents. Consider starting your webhook channel visible only to staff while testing.

## Files

- `.github/workflows/town-bulletin.yml` — scheduling and manual workflow UI
- `post_bulletin.py` — send one event via Discord webhook
- `bot.py` — optional interactive slash-command Discord bot
- `events.py` — common event selection and embed formatting
- `data/events.json` — fictional prompts plus sourced real history
- `.env.example`, `.gitignore`, `requirements.txt` — configuration
